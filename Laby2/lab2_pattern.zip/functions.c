/* Distributed Programming
   Lab2 - libraries - example

   (C) by Mariusz Matuszek
   Gdańsk University of Technology
*/


// function definition(s)

#include "types.h"

int add(data_t x, data_t y) {
  return(x.a + x.b + y.a + y.b);
}

